HDReenable
===========

A small macOS menu-bar utility that automatically enables HDR mode on external displays using the SkyLight private APIs. Polling rate is configurable.

Run
---

To run the bundle:

Control‑click `HDReenable.app` → Open → click Open. In System Settings under Privacy & Security find the Security section and select "Open anyway" to allow the app to be run.

- Terminal (one‑time):
	```bash
	xattr -rd com.apple.quarantine /path/to/HDReenable.app
	```
- Admin (add Gatekeeper rule):
	```bash
	sudo spctl --add /path/to/HDReenable.app
	```

Acknowledgements
-------

Thanks to [hoder](https://github.com/kohlschuetter/hoder) for the inspiration.

License
-------
MIT

---

## Release notes

### 1.0.2 (2025-12-28)

- Added application icon

### 1.0.1 (2025-12-28)

- statusbar: refresh HDR label when menu opens; show "HDR: Checking..." while querying the display

### 1.0.0 (2025-12-27)

- Initial release
